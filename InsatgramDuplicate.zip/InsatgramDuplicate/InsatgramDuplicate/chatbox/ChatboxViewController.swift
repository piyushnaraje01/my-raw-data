//
//  ChatboxViewController.swift
//  InsatgramDuplicate

//

import UIKit
import Kingfisher

class ChatboxViewController: UIViewController {
    
    
    @IBOutlet weak var searchbar: UISearchBar!
    @IBOutlet weak var tableview: UITableView!
    var heroes = [HeroStats]()
    var dataHeroes = [HeroStats]()
    var dataCountChats = 10
    var oldDataCountChats = 10
    override func viewDidLoad() {
        super.viewDidLoad()
        self.searchbar.delegate = self
        downloadjson {
            self.tableview.reloadData()
        
        }
    }
    
    @objc func addDataForChats(){
        self.dataCountChats += 10
        for i in oldDataCountChats...dataCountChats - 1{
            if  i <= dataCountChats{
                self.dataHeroes.append(self.heroes[i])
            }
        }
        self.oldDataCountChats = self.dataCountChats
        self.tableview.reloadData()
    }
    @IBAction func cerambutton(_ sender: UIButton) {
        let alrt = UIAlertController(title: " Error ", message: " Sorry Cemera is not Working! ", preferredStyle: .alert)
//                   let firstAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                   let secondAction = UIAlertAction(title: "OK", style: .default, handler: nil)
//                   alrt.addAction(firstAction)
                   alrt.addAction(secondAction)
                   present(alrt, animated: true, completion: nil)
                   

    }
    
    func downloadjson(completed:@escaping () -> ()) {
        let url = URL(string: "https://api.opendota.com/api/heroStats")
        URLSession.shared.dataTask(with: url!) { data, response, error in
            if error == nil{
                do {
                    self.heroes = try JSONDecoder().decode([HeroStats].self, from: data!)
                    self.heroes = try JSONDecoder().decode([HeroStats].self, from: data!)
                    for i in 0...self.heroes.count - 1{
                        if i < self.dataCountChats{
                            self.dataHeroes.append(self.heroes[i])
                        }
                    }
                    DispatchQueue.main.async {
                        completed()
                    }
                }
                catch{
    //                   let sc = UIStoryboard(name: "Main", bundle: nil)
    //                    let vc = sc.instantiateViewController(withIdentifier: "helloerror")
    //                    self.show(vc, sender: self)
                    print("I have error")
                }
            }
        } .resume()
    }

}

extension ChatboxViewController: UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataHeroes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "chatboxTableViewCell", for: indexPath) as! chatboxTableViewCell

        cell.namelbl.text = dataHeroes[indexPath.row].localized_name
//        MARK: imp VVIP
        
        guard let url = URL(string: "https://api.opendota.com" + heroes[indexPath.row].img)
        else {
            return UITableViewCell()
            
        }
        let processor = DownsamplingImageProcessor(size: cell.chatlogoimg.bounds.size)
                     |> RoundCornerImageProcessor(cornerRadius: 20)
        cell.chatlogoimg.kf.indicatorType = .activity
        cell.chatlogoimg.kf.setImage(
            with: url,
            placeholder: UIImage(named: "placeholderImage"),
            options: [
                .processor(processor),
                .scaleFactor(UIScreen.main.scale),
                .transition(.fade(1)),
                .cacheOriginalImage
            ])
            cell.chatlogoimg.contentMode = .scaleToFill
            cell.chatlogoimg.layer.cornerRadius = 25
        if indexPath.section == 0{
            cell.btnAddChat.addTarget(self, action: #selector(addDataForChats), for: .touchUpInside)
            if indexPath.row == dataHeroes.count - 1{
                cell.chatlogoimg.isHidden = true
                cell.namelbl.isHidden = true
                cell.btnCamera.isHidden = true
                cell.btnAddChat.isHidden = false
            }else{
                cell.chatlogoimg.isHidden = false
                cell.namelbl.isHidden = false
                cell.btnCamera.isHidden = false
                cell.btnAddChat.isHidden = true
            }
        }
        return cell
       
    }
        
//        cell.charactericon.image = UIImage(named: myHero)
       
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//
//        performSegue(withIdentifier: "showDetails", sender: self)
//        }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if let destination = segue.destination as? HeroresViewController{
//            destination.hero = heroes[(tableview.indexPathForSelectedRow?.row)!]
//        }
//    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showDetails", sender: self)
        }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? chatViewController{
            destination.hero = heroes[(tableview.indexPathForSelectedRow?.row)!]
        }
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//         var filteredMenu = [Any]()
        if searchText == ""{
            downloadjson {
                self.tableview.reloadData()
            }
        }else{
            heroes = heroes.filter({(heroes) -> Bool in
                return heroes.localized_name.contains(searchText)
            })
        }
        self.tableview.reloadData()
    }
}
