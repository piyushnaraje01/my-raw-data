//
//  chatboxTableViewCell.swift
//  InsatgramDuplicate

//

import UIKit

class chatboxTableViewCell: UITableViewCell {

    @IBOutlet var btnCamera: UIButton!
    @IBOutlet var btnAddChat: UIButton!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var chatlogoimg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
}
