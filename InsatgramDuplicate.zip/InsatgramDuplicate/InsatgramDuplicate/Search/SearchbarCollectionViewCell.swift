//
//  SearchbarCollectionViewCell.swift
//  InsatgramDuplicate

//

import UIKit

class SearchbarCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var postimg: UIImageView!
    @IBOutlet weak var namelbl: UILabel!
}
