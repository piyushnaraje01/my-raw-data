//
//  SearchViewController.swift
//  InsatgramDuplicate

//

import UIKit

class SearchViewController: UIViewController {
    var heroes = [HeroStats]()
    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet weak var searchbar: UISearchBar!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.searchbar.delegate = self
        downloadjson {
            self.collectionview.reloadData()
        }
        collectionview.collectionViewLayout = layout()
        
    }
    func downloadjson(completed:@escaping () -> ()) {
        let url = URL(string: "https://m2knews-default-rtdb.firebaseio.com/")
        URLSession.shared.dataTask(with: url!) { data, response, error in
            if error == nil{
                do {
                    self.heroes = try JSONDecoder().decode([HeroStats].self, from: data!)
                    
                    DispatchQueue.main.async {
                        completed()
                    }
                }
                catch{
                    print("I have error")
                }
            }
        } .resume()
    }
    func layout() -> UICollectionViewCompositionalLayout{
        let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                            layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in

            switch sectionIndex{



            case 1:
                let itemsSize = NSCollectionLayoutSize(
                    widthDimension: .absolute(80),
                    heightDimension: .absolute(80)
                )
                let item = NSCollectionLayoutItem(layoutSize: itemsSize)
                //        item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)

                let groupSize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1/4),
                    heightDimension: .fractionalWidth(1/4)
                )
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
                //                group.interItemSpacing = .fixed(5)

                let section = NSCollectionLayoutSection(group: group)

                section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary

                return section
//
            default:
                let itemsize = NSCollectionLayoutSize(
                    widthDimension: .absolute(200),
                    heightDimension: .absolute(200)
                )

                let item = NSCollectionLayoutItem(layoutSize: itemsize)
                item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)
                let groupsize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1),
                    heightDimension: .fractionalHeight(1/4.5)
                )
//                item.contentInsets.leading = 10
                //                let group = NSCollectionLayoutGroup.vertical(layoutSize: groupsize, subitems: [item])
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupsize, subitems: [item])
                let section = NSCollectionLayoutSection(group: group)

                return section
            }
        }
        return layout
    }
}
extension SearchViewController: UICollectionViewDelegate,UICollectionViewDataSource,UISearchBarDelegate{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return heroes.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "SearchbarCollectionViewCell", for: indexPath) as! SearchbarCollectionViewCell
        guard let url = URL(string: "https://api.opendota.com" + heroes[indexPath.row].img)
        else {
            return UICollectionViewCell()
        }
        
        if let data = try? Data(contentsOf: url) {
            cell.postimg.image = UIImage(data: data)
        }
        cell.postimg.contentMode = .scaleAspectFill
        cell.namelbl.text = heroes[indexPath.row].localized_name
    return cell
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//         var filteredMenu = [Any]()
        if searchText == ""{
            downloadjson {
                self.collectionview.reloadData()
            }
        }else{
            heroes = heroes.filter({(heroes) -> Bool in
                return heroes.localized_name.contains(searchText)
            })
        }
        self.collectionview.reloadData()
    }
    
}
