////
////  JasonDownload.swift
////  InsatgramDuplicate
////
//
//import Foundation
//import UIKit
//func downloadjson(completed:@escaping () -> ()) {
//    let url = URL(string: "https://api.opendota.com/api/heroStats")
//    URLSession.shared.dataTask(with: url!) { data, response, error in
//        if error == nil{
//            do {
//                self.heroes = try JSONDecoder().decode([HeroStats].self, from: data!)
//                
//                DispatchQueue.main.async {
//                    completed()
//                }
//            }
//            catch{
////                   let sc = UIStoryboard(name: "Main", bundle: nil)
////                    let vc = sc.instantiateViewController(withIdentifier: "helloerror")
////                    self.show(vc, sender: self)
//                print("I have error")
//            }
//        }
//    } .resume()
//}
//
