//
//  ViewController.swift
//  InsatgramDuplicate

//

import UIKit
import Kingfisher

class ViewController: UIViewController {
    @IBOutlet weak var collectiionview: UICollectionView!
    var heroes = [HeroStats]()
    var dataHerosPost = [HeroStats]()
    var dataHerosStories = [HeroStats]()
    var datacountPost: Int = 10
    var newDataCountPost: Int = 10
    var dataCountStories: Int = 10
    var newDataCountStories: Int = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        navigationController?.navigationBar.tintColor = .label
        downloadjson {
        }
        collectiionview.collectionViewLayout = layout()
        self.collectiionview.register(UINib(nibName: "homepostsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "homepostsCollectionViewCell")
        configureItems()
        
    }
    
    @IBAction func sharepost(_ sender: UIButton) {
        let sc = UIStoryboard(name: "Main", bundle: nil)
        let vc = sc.instantiateViewController(withIdentifier: "ChatboxViewController") as! ChatboxViewController
        present(vc, animated: true, completion: nil)
    }
    @objc func openstory(){
        let sc = UIStoryboard(name: "Main", bundle: nil)
        let vc = sc.instantiateViewController(withIdentifier: "storiesViewController") as! storiesViewController
        present(vc, animated: true, completion: nil)
    }
    @objc func addPostData(){
        self.datacountPost += 10
        for i in self.newDataCountPost...datacountPost - 1{
            if  i <= datacountPost && i < self.heroes.count - 1{
                self.dataHerosPost.append(self.heroes[i])
            }
        }
        self.newDataCountPost = self.datacountPost
        self.collectiionview.reloadData()

    }
    @objc func addStoriesData(){
        self.dataCountStories += 10
        for i in self.newDataCountStories...dataCountStories - 1{
            if  i <= dataCountStories && i < self.heroes.count - 1{
                self.dataHerosStories.append(self.heroes[i])
            }
        }
        self.newDataCountStories = self.dataCountStories
        self.collectiionview.reloadData()

    }
    private func configureItems(){
//        self.navigationItem.rightBarButtonItem = UIBarButtonItem(
//            title: "ChatBoxff" , style: .done, target: self, action: #selector(didtapButton)
//        )
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(named: "chaticon"), style: .done, target: self, action: #selector(didtapButton))
//
    }
    @objc func didtapButton(){
        let sc = UIStoryboard(name: "Main", bundle: nil)
        let vc = sc.instantiateViewController(withIdentifier: "ChatboxViewController") as! ChatboxViewController
        vc.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: .none, action: nil)
        navigationController?.pushViewController(vc, animated: true)
    }

    
    
    func downloadjson(completed:@escaping () -> ()) {
        let url = URL(string: "https://api.opendota.com/api/heroStats")
        URLSession.shared.dataTask(with: url!) { data, response, error in
            if error == nil{
                do {
                    self.heroes = try JSONDecoder().decode([HeroStats].self, from: data!)
                    for i in 0...self.heroes.count - 1{
                        if i < self.datacountPost {
                            self.dataHerosStories.append(self.heroes[i])
                            self.dataHerosPost.append(self.heroes[i])
                        }
                    }
                    DispatchQueue.main.async {
                        completed()
                        self.collectiionview.reloadData()
                    }
                }
                catch{
                    print("I have error")
                }
            }
        } .resume()
    }
    
    
    func layout() -> UICollectionViewCompositionalLayout{
        let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                            layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in

            switch sectionIndex{
            case 0:
                let itemsSize = NSCollectionLayoutSize(
                    widthDimension: .absolute(100),
                    heightDimension: .absolute(100)
                )
                let item = NSCollectionLayoutItem(layoutSize: itemsSize)
                // item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)

                let groupSize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1/4),
                    heightDimension: .fractionalWidth(1/4)
                )
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
                //                group.interItemSpacing = .fixed(5)

                let section = NSCollectionLayoutSection(group: group)

                section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary

                return section
//
            default:
                let itemsize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1),
                    heightDimension: .absolute(500)
                )

                let item = NSCollectionLayoutItem(layoutSize: itemsize)
                item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)
                let groupsize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1),
                    heightDimension: .fractionalHeight(0.68)
                )
//                item.contentInsets.leading = 10
                //                let group = NSCollectionLayoutGroup.vertical(layoutSize: groupsize, subitems: [item])
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupsize, subitems: [item])
                let section = NSCollectionLayoutSection(group: group)

                return section
            }
        }
        return layout
    }


}
extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0{
            return dataHerosStories.count
        }else{
            return dataHerosPost.count
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        switch indexPath.section{
        case 0 :
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "postbannerCollectionViewCell", for: indexPath) as! postbannerCollectionViewCell
            if indexPath.row == dataHerosStories.count - 1{
                cell.storiesimg.isHidden = true
                cell.storieslbl.isHidden = true
                cell.btnAddStories.isHidden = false
            }else{
                cell.storiesimg.isHidden = false
                cell.storieslbl.isHidden = false
                cell.btnAddStories.isHidden = true
            }
            guard let url = URL(string: "https://api.opendota.com" + heroes[indexPath.row].img)
            else {
                return UICollectionViewCell()
            }
            let processor = DownsamplingImageProcessor(size: cell.storiesimg.bounds.size)
                         |> RoundCornerImageProcessor(cornerRadius: 20)
            cell.storiesimg.kf.indicatorType = .activity
            cell.storiesimg.kf.setImage(
                with: url,
                placeholder: UIImage(named: "placeholderImage"),
                options: [
                    .processor(processor),
                    .scaleFactor(UIScreen.main.scale),
                    .transition(.fade(1)),
                    .cacheOriginalImage
                ])
            cell.btnAddStories.addTarget(self, action: #selector(addStoriesData), for: .touchUpInside)
            cell.storieslbl.text = dataHerosStories[indexPath.row].localized_name
            return cell
        default :
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "postsCollectionViewCell", for: indexPath) as! postsCollectionViewCell
            if indexPath.row == dataHerosPost.count - 1{
                cell.characternamelbl.isHidden = true
                cell.postbannerimg.isHidden = true
                cell.logoimg.isHidden = true
                cell.likebutton.isHidden = true
                cell.btnAddPost.isHidden = false
                cell.lblDescription.isHidden = false
                cell.btnComments.isHidden = true
                cell.btnShare.isHidden = true
                cell.lbltext.isHidden = true
                cell.lbllike.isHidden = true
                cell.characternamelsbl.isHidden = true
                cell.viewBlack.backgroundColor = .white
            }else{
                cell.characternamelbl.isHidden = false
                cell.postbannerimg.isHidden = false
                cell.logoimg.isHidden = false
                cell.likebutton.isHidden = false
                cell.btnAddPost.isHidden = true
                cell.lblDescription.isHidden = true
                cell.characternamelsbl.isHidden = false
                cell.lbllike.isHidden = false
                cell.btnShare.isHidden = false
                cell.btnComments.isHidden = false
                cell.viewBlack.backgroundColor = .black
            }
            
            
            guard let url = URL(string: "https://api.opendota.com" + heroes[indexPath.row].img)
            else {
                return UICollectionViewCell()
            }
            let processor = DownsamplingImageProcessor(size: cell.postbannerimg.bounds.size)
                         |> RoundCornerImageProcessor(cornerRadius: 20)
            cell.postbannerimg.kf.indicatorType = .activity
            cell.postbannerimg.kf.setImage(
                with: url,
                placeholder: UIImage(named: "placeholderImage"),
                options: [
                    .processor(processor),
                    .scaleFactor(UIScreen.main.scale),
                    .transition(.fade(1)),
                    .cacheOriginalImage
                ])
            
                cell.logoimg.layer.cornerRadius = 25
                cell.logoimg.downloaded(from: url)
            cell.logoimg.contentMode = .scaleAspectFit
            
                cell.postbannerimg.contentMode = .scaleToFill
            
            cell.characternamelbl.text = heroes[indexPath.row].localized_name
            cell.characternamelsbl.text = heroes[indexPath.row].localized_name
            cell.btnAddPost.addTarget(self, action: #selector(addPostData), for: .touchUpInside)
          //  cell.selectionStyle = .none
    return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            let sc = UIStoryboard(name: "Main", bundle: nil)
            let vc = sc.instantiateViewController(withIdentifier: "storiesViewController") as! storiesViewController
            present(vc, animated: true, completion: nil)
        }
    }

}
