//
//  postbannerCollectionViewCell.swift
//  InsatgramDuplicate

//

import UIKit

class postbannerCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var btnAddStories: UIButton!
    @IBOutlet weak var storieslbl: UILabel!
    @IBOutlet weak var storiesimg: UIImageView!
}
