//
//  postsCollectionViewCell.swift
//  InsatgramDuplicate

//

import UIKit

class postsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var btnAddPost: UIButton!
    @IBOutlet weak var likebutton: UIButton!
    @IBOutlet weak var characternamelsbl: UILabel!
    @IBOutlet weak var postbannerimg: UIImageView!
    @IBOutlet weak var characternamelbl: UILabel!
    @IBOutlet weak var logoimg: UIImageView!
    @IBOutlet var lbltext: UILabel!
    @IBOutlet var btnShare: UIButton!
    @IBOutlet var lblDescription: UILabel!
    @IBOutlet var btnComments: UIButton!
    @IBOutlet var lbllike: UILabel!
    @IBOutlet var viewBlack: UIView!
    //    override class func awakeFromNib() {
//
//    }
//
    
    @IBAction func chnagelikevcolor(_ sender: UIButton) {
        chnagelikebuttoncolor()
    }
    @objc func chnagelikebuttoncolor(){
        likebutton.backgroundColor = .red
    }
}

