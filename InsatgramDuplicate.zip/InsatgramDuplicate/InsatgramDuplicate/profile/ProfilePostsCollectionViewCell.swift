//
//  ProfilePostsCollectionViewCell.swift
//  InsatgramDuplicate
//

import UIKit

class ProfilePostsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var btnAdd: UIButton!
    @IBOutlet weak var profilesposts: UIImageView!
}
