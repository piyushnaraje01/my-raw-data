//
//  ProfileViewController.swift
//  InsatgramDuplicate


import UIKit


class ProfileViewController: UIViewController {
    
    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet weak var profilephoto: UIImageView!
    var heroes = [HeroStats]()
    var dataHeroesStories = [HeroStats]()
    var dataHeroesPost = [HeroStats]()
    var dataCountStories = 10
    var oldDataCountStories = 10
    var dataCountPosts = 10
    var oldDataCountPosts = 10
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        profilephoto.addGestureRecognizer(tapGesture)
        profilephoto.isUserInteractionEnabled = true
        
        downloadjson {
            self.collectionview.reloadData()
        }
        
        
        collectionview.collectionViewLayout = layout()
        profilephoto.layer.cornerRadius = 50
        profilephoto.layer.masksToBounds = true
    }
    
    
    @IBAction func editprofile(_ sender: UIButton) {
        let alrt = UIAlertController(title: " Edir Profile", message: "You can chnage your setting here", preferredStyle: .actionSheet)
                 let firstAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                 let secondAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        let fourthAction = UIAlertAction(title: "Setting", style: .default, handler: nil)
        let fifthAction = UIAlertAction(title: "Archieve", style: .default, handler: nil)
        let sixAction = UIAlertAction(title: "Your activity", style: .default, handler: nil)
        let sevenAction = UIAlertAction(title: "QR code", style: .default, handler: nil)
        let eightAction = UIAlertAction(title: "Saved", style: .default, handler: nil)
        let nineAction = UIAlertAction(title: "Close friends", style: .default, handler: nil)
                 alrt.addAction(firstAction)
                 alrt.addAction(secondAction)
        alrt.addAction(fourthAction)
        alrt.addAction(fifthAction)
        alrt.addAction(sixAction)
        alrt.addAction(sevenAction)
        alrt.addAction(eightAction)
        alrt.addAction(nineAction)
                 present(alrt, animated: true, completion: nil)

    }
    @objc func addDataForStories(){
        self.dataCountStories += 10
        for i in oldDataCountStories...dataCountStories - 1{
            if  i <= dataCountStories && i < self.dataHeroesStories.count - 1{
                self.dataHeroesStories.append(self.heroes[i])
            }
        }
        self.oldDataCountStories = self.dataCountStories
        self.collectionview.reloadData()
    }
    @objc func addDataForPosts(){
        self.dataCountPosts += 10
        for i in oldDataCountPosts ... dataCountPosts - 1{
            if  i <= dataCountPosts{
                self.dataHeroesPost.append(self.heroes[i])
            }
        }
        self.oldDataCountPosts = self.dataCountPosts
        self.collectionview.reloadData()
    }
    func downloadjson(completed:@escaping () -> ()) {
        let url = URL(string: "https://api.opendota.com/api/heroStats")
        URLSession.shared.dataTask(with: url!) { data, response, error in
            if error == nil{
                do {
                    self.heroes = try JSONDecoder().decode([HeroStats].self, from: data!)
                    for i in 0...self.heroes.count - 1{
                        if i < self.dataCountPosts{
                            self.dataHeroesStories.append(self.heroes[i])
                            self.dataHeroesPost.append(self.heroes[i])
                        }
                    }
                    DispatchQueue.main.async {
                        completed()
                    }
                }
                catch{
    //                   let sc = UIStoryboard(name: "Main", bundle: nil)
    //                    let vc = sc.instantiateViewController(withIdentifier: "helloerror")
    //                    self.show(vc, sender: self)
                    print("I have error")
                }
            }
        } .resume()
    }

    @IBAction func profilesegmentcontrol(_ sender: UISegmentedControl) {
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        print("Image Tapped")
        openGallery()
    }
    func layout() -> UICollectionViewCompositionalLayout{
        let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                            layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in
            
            switch sectionIndex{
                

                
            case 0:
                let itemsSize = NSCollectionLayoutSize(
                    widthDimension: .absolute(80),
                    heightDimension: .absolute(80)
                )
                let item = NSCollectionLayoutItem(layoutSize: itemsSize)
                //        item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)
                
                let groupSize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1/4),
                    heightDimension: .fractionalWidth(1/4)
                )
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
                //                group.interItemSpacing = .fixed(5)
                
                let section = NSCollectionLayoutSection(group: group)
                
                section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary
                
                return section
      
            default:
                let itemsize = NSCollectionLayoutSize(
                    widthDimension: .absolute(135),
                    heightDimension: .absolute(90)
                )
                
                let item = NSCollectionLayoutItem(layoutSize: itemsize)
//                item.contentInsets = NSDirectionalEdgeInsets(top: 15, leading: 15, bottom: 15, trailing: 15)
                let groupsize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1),
                    heightDimension: .fractionalHeight(1/4.5)
                )
//                item.contentInsets.leading = 10
                //                let group = NSCollectionLayoutGroup.vertical(layoutSize: groupsize, subitems: [item])
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupsize, subitems: [item])
                let section = NSCollectionLayoutSection(group: group)
           
                return section
            }
        }
        return layout
    }


}
extension ProfileViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0{
            return dataHeroesStories.count
        }else{
            return dataHeroesPost.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProfilePostsCollectionViewCell", for: indexPath) as! ProfilePostsCollectionViewCell

//        cell.profilesposts.image = UIImage(named: "Shravnee Dongre")
        switch indexPath.section{
        case 0:
            cell.profilesposts.contentMode = .scaleAspectFill
            cell.profilesposts.layer.cornerRadius = 40
            guard let url = URL(string: "https://api.opendota.com" + dataHeroesStories[indexPath.row].img)
            else {
                return UICollectionViewCell()
            }
            let processor = DownsamplingImageProcessor(size: cell.profilesposts.bounds.size)
                         |> RoundCornerImageProcessor(cornerRadius: 20)
            cell.profilesposts.kf.indicatorType = .activity
            cell.profilesposts.kf.setImage(
                with: url,
                placeholder: UIImage(named: "placeholderImage"),
                options: [
                    .processor(processor),
                    .scaleFactor(UIScreen.main.scale),
                    .transition(.fade(1)),
                    .cacheOriginalImage
                ])
            

        default:
            cell.profilesposts.contentMode = .scaleAspectFill
            guard let url = URL(string: "https://api.opendota.com" + dataHeroesPost[indexPath.row].img)
            else {
                return UICollectionViewCell()
            }
            let processor = DownsamplingImageProcessor(size: cell.profilesposts.bounds.size)
                         |> RoundCornerImageProcessor(cornerRadius: 20)
            cell.profilesposts.kf.indicatorType = .activity
            cell.profilesposts.kf.setImage(
                with: url,
                placeholder: UIImage(named: "placeholderImage"),
                options: [
                    .processor(processor),
                    .scaleFactor(UIScreen.main.scale),
                    .transition(.fade(1)),
                    .cacheOriginalImage
                ])
            
        }

        if indexPath.section == 0{
            cell.btnAdd.addTarget(self, action: #selector(addDataForStories), for: .touchUpInside)
            if indexPath.row == dataHeroesStories.count - 1{
                cell.profilesposts.isHidden = true
                cell.btnAdd.isHidden = false
            }else{
                cell.profilesposts.isHidden = false
                cell.btnAdd.isHidden = true
            }
        }else{
            cell.btnAdd.addTarget(self, action: #selector(addDataForPosts), for: .touchUpInside)
            if indexPath.row == dataHeroesPost.count - 1{
                cell.profilesposts.isHidden = true
                cell.btnAdd.isHidden = false
            }else{
                cell.profilesposts.isHidden = false
                cell.btnAdd.isHidden = true
            }
        }
    return cell
    }
    

}
extension ProfileViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate{

    func openGallery(){
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .savedPhotosAlbum
            present(picker, animated: true)
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let img = info[.originalImage] as? UIImage{
            profilephoto.image = img
        }
        dismiss(animated: true)
    }
}
