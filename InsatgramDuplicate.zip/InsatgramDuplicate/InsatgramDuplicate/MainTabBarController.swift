//
//  MainTabBarController.swift
//  InsatgramDuplicate
//
//  Created by Piyush Naranje on 04/09/22.
//

import UIKit
class MainTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
