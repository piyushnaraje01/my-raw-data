//
//  storiesCollectionViewCell.swift
//  InsatgramDuplicate

//

import UIKit

class storiesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var bannerimg: UIImageView!
    @IBOutlet weak var characternamelbl: UILabel!
    @IBOutlet weak var characterlogogimg: UIImageView!
}
