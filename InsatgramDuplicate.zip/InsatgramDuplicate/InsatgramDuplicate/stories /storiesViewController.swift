//
//  storiesViewController.swift
//  InsatgramDuplicate

//

import UIKit

class storiesViewController: UIViewController {
    var timer: Timer?
    var currentcellIndex = 0
    var heroes = [HeroStats]()
    @IBOutlet weak var collectionview: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionview.collectionViewLayout = layout()
        timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(slideToNext), userInfo: nil, repeats: true)
        downloadjson {
            self.collectionview.reloadData()
        }
       
    }
    @IBAction func sendmessage(_ sender: UIButton) {
        let sc = UIStoryboard(name: "Main", bundle: nil)
        let vc = sc.instantiateViewController(withIdentifier: "ChatboxViewController") as! ChatboxViewController
        present(vc, animated: true, completion: nil)
    }
    
    @objc func slideToNext(){
        if currentcellIndex < heroes.count - 1 {
            currentcellIndex = currentcellIndex + 1
//            pagecontroller.currentPage = currentcellIndex
        }else{
            currentcellIndex = 0
//            pagecontroller.currentPage = currentcellIndex
        }
        collectionview.scrollToItem(at: IndexPath(item: currentcellIndex, section: 0), at: .right, animated: true)
    }
    
    
 
    
    func downloadjson(completed:@escaping () -> ()) {
        let url = URL(string: "https://api.opendota.com/api/heroStats")
        URLSession.shared.dataTask(with: url!) { data, response, error in
            if error == nil{
                do {
                    self.heroes = try JSONDecoder().decode([HeroStats].self, from: data!)
                    
                    DispatchQueue.main.async {
                        completed()
                    }
                }
                catch{
    //                   let sc = UIStoryboard(name: "Main", bundle: nil)
    //                    let vc = sc.instantiateViewController(withIdentifier: "helloerror")
    //                    self.show(vc, sender: self)
                    print("I have error")
                }
            }
        } .resume()
    }
    func layout() -> UICollectionViewCompositionalLayout{
        let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                            layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in
            
            switch sectionIndex{
                

                
            case 1:
                let itemsSize = NSCollectionLayoutSize(
                    widthDimension: .absolute(80),
                    heightDimension: .absolute(80)
                )
                let item = NSCollectionLayoutItem(layoutSize: itemsSize)
                //        item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)
                
                let groupSize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1/4),
                    heightDimension: .fractionalWidth(1/4)
                )
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
                //                group.interItemSpacing = .fixed(5)
                
                let section = NSCollectionLayoutSection(group: group)
                
                section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary
                
                return section
      
            default:
                let itemsize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1),
                    heightDimension: .absolute(800)
                )
                
                let item = NSCollectionLayoutItem(layoutSize: itemsize)
//                item.contentInsets = NSDirectionalEdgeInsets(top: 15, leading: 15, bottom: 15, trailing: 15)
                let groupsize = NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1),
                    heightDimension: .fractionalHeight(1/0.68)
                )
//                item.contentInsets.leading = 10
                //                let group = NSCollectionLayoutGroup.vertical(layoutSize: groupsize, subitems: [item])
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupsize, subitems: [item])
                let section = NSCollectionLayoutSection(group: group)
                section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary
                return section
            }
        }
        return layout
    }
    

}
extension storiesViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return heroes.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "storiesCollectionViewCell", for: indexPath) as! storiesCollectionViewCell
        cell.characternamelbl.text
        guard let url = URL(string: "https://api.opendota.com" + heroes[indexPath.row].img)
        else {
            return UICollectionViewCell()
        }
        
        if let data = try? Data(contentsOf: url) {
            cell.characterlogogimg.image = UIImage(data: data)
            cell.bannerimg.image = UIImage(data: data)
            cell.characterlogogimg.contentMode = .scaleToFill
            cell.characterlogogimg.layer.cornerRadius = 25
            cell.bannerimg.contentMode = .scaleToFill
        }
        return cell
    }
    
    
    
}

